package com.harish.dreambuckets.models

data class CategoriesModel(val categoryName: String, val Image: Int)