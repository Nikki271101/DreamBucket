package com.harish.dreambuckets.models

data class HomeDisplayModel(
    var bucketName: String,
    var bucketThoughts : String
)
